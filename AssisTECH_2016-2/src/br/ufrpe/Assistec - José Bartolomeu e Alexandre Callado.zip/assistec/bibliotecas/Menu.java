package br.ufrpe.assistec.bibliotecas;

public class Menu {
	public void preencherOS() {
		
	}
}
